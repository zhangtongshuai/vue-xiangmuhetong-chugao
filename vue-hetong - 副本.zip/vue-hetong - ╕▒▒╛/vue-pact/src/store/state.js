const state = {
  user: null,
  token: '',
  type: '',
  realname: '',
  phone: ''
};

export default state;
