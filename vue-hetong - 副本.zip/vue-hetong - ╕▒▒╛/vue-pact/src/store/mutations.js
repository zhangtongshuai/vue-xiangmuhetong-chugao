import { sessionStorage } from 'src/assets/js/storage';

const mutations = {
  SET_USER (state, user) {
    state.user = user;
    sessionStorage.setItem('user', user);
  },
  SET_TOKEN (state, token) {
    state.token = token;
    sessionStorage.setItem('token', token);
  },
  TYPE (state, type) {
    state.type = type;
    sessionStorage.setItem('type', type);
  },
  REAL_NAME (state, realname) {
    state.realname = realname;
    sessionStorage.setItem('realname', realname);
  },
  PHONE (state, phone) {
    state.phone = phone;
    sessionStorage.setItem('phone', phone);
  }
};

export default mutations;

