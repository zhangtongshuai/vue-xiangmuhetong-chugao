const baseURL = 'http://192.168.0.134:8080/agreement_service/';
const token = '83359fd73fe94948385f570e3c139166';
const userSite = '林花落了春红，太匆匆';
export default {
  baseURL,
  token,
  userSite
}
