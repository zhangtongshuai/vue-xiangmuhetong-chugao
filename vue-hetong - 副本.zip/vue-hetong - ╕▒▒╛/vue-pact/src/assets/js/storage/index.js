/**
 * @Project Name: dogma
 * @Author: luichooy
 * @Date: 2018-04-10 14:05
 * @Email: luichooy@163.com
 * @Idea: WebStorm
 */


export {default as localStorage} from './localStorage';

export {default as sessionStorage} from './sessionStorage';
