<template>
  <div id="root" class="root">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {}
</script>

<style lang="scss" scoped>
  .root{
    width: 100%;
    height: 100%;
  }
</style>
