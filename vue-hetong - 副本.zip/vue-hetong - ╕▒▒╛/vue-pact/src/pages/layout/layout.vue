<template>
  <div class="layout">
    <div class="siderbar-wrapper" :style="{width: this.isCollapsed?'64px':'200px'}">
      <div class="logo-wrapper">
        <div v-if='user.type == 1'>企业</div>
        <div v-if='user.type == 0'>个人</div>
      </div>
      <el-menu
        background-color="#424f63"
        text-color="#fff"
        active-text-color="#65cea7"
        class="menu-wrapper"
        router
        unique-opened
        :collapse="isCollapsed"
        :default-active="$route.path" v-if='user.type == 1'>
        <template v-for="(item, index) in sider_menu_data">
          <el-menu-item class="menu-item" v-if="!item.children" :index="item.path" :key="index">
            <i :class="item.icon"></i>
            <span slot="title">{{item.title}}</span>
          </el-menu-item>
          <el-submenu v-else :index="item.path">
            <template slot="title">
              <i :class="item.icon"></i>
              <span slot="title">{{item.title}}</span>
            </template>
            <el-menu-item class="menu-item" v-for="(sub_item, sub_index) in item.children" :index="sub_item.path"
                          :key="sub_index">
              <span slot="title" style="margin-left:12px;">{{sub_item.title}}</span>
            </el-menu-item>
          </el-submenu>
        </template>
      </el-menu>
      <el-menu
        background-color="#424f63"
        text-color="#fff"
        active-text-color="#65cea7"
        class="menu-wrapper"
        router
        unique-opened
        :collapse="isCollapsed"
        :default-active="$route.path" v-if='user.type == 0'>
        <template v-for="(item, index) in sider_menu_data0">
          <el-menu-item class="menu-item" v-if="!item.children" :index="item.path" :key="index">
            <i :class="item.icon"></i>
            <span slot="title">{{item.title}}</span>
          </el-menu-item>
          <el-submenu v-else :index="item.path">
            <template slot="title">
              <i :class="item.icon"></i>
              <span slot="title">{{item.title}}</span>
            </template>
            <el-menu-item class="menu-item" v-for="(sub_item, sub_index) in item.children" :index="sub_item.path"
                          :key="sub_index">
              <span slot="title" style="margin-left:12px;">{{sub_item.title}}</span>
            </el-menu-item>
          </el-submenu>
        </template>
      </el-menu>
    </div>
    <div class="topbar-wrapper" :style="{left: this.isCollapsed?'64px':'200px'}">
      <div class="menu-collapse-wrapper float-left" @click="toggleMenu">
        <i class="el-icon-adm-menu" :style="{transform: 'rotateZ(' + (this.isCollapsed ? '90' : '0') + 'deg)'}"></i>
      </div>
      <div class="title float-left">项目管理 后台管理系统</div>
      <ul class="menu-list float-right">
        <li v-if="user" class="menu-item" style="padding: 0;">
          <el-dropdown
            :show-timeout="10"
            :hide-timeout="10"
            @command="handleCommand"
            style="padding: 0 15px;">
            <div class="dropdown-content el-dropdown-link user_info">
              <i v-if="!user.headimg || user.headimg == ''" class="icon el-icon-adm-usersetup"></i>
              <img v-if="user.headimg && user.headimg != ''" :src="user.headimg" class="user_headimg">
              <span class="text">{{user.phone}}</span>
              <span class="text">({{user.realname}})</span>
            </div>
            <el-dropdown-menu slot="dropdown">
              <!-- <el-dropdown-item command="a">{{user.phone}}</el-dropdown-item>
              <el-dropdown-item command="b">{{user.phone}}</el-dropdown-item>
              <el-dropdown-item command="b">{{user.phone}}</el-dropdown-item> -->
            </el-dropdown-menu>
          </el-dropdown>
        </li>
        <!-- <li class="menu-item">
          <i class="icon el-icon-adm-help"></i>
        </li> -->
        <li class="menu-item" @click="exit">
          <i class="icon iconfont el-icon-adm-exit"></i>
        </li>
      </ul>
    </div>
    <div class="content-wrapper" ref="content-wrapper" :style="{left: this.isCollapsed?'64px':'200px'}">
      <div class="content">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>
<script>
  import {sessionStorage} from 'src/assets/js/storage';
  
  export default {
    created() {
      this.checkAuth();
    },
    data() {
      return {
        user: {},
        sider_menu_data: [
          {
            path: '/home',
            title: '事务管理',
            icon: 'el-icon-adm-home'
          },
          // {
          //   path: '/tables',
          //   title: '表格管理',
          //   icon: 'el-icon-adm-linechart',
          //   children: [
          //     {path: '/tables/basic', title: '基本表格'},
          //     {path: '/tables/sort', title: '排序表格'},
          //     {path: '/tables/filter', title: '筛选表格'}
          //   ]
          // },
          // {
          //   path: '/charts',
          //   title: '图表管理',
          //   icon: 'el-icon-adm-statistics',
          //   children: [
          //     {path: '/charts/bar', title: '柱状图'},
          //     {path: '/charts/line', title: '折线图'},
          //     {path: '/charts/pie', title: '饼图'}
          //   ]
          // },
          // {
          //   path: '/form',
          //   title: '表单管理',
          //   icon: 'el-icon-adm-form',
          //   children: [
          //     {path: '/form/render', title: '渲染表单'}
          //   ]
          // },
          {
            path: '/system/index',
            title: '过期事务',
            icon: 'el-icon-adm-project'
          },
          {
            path: '/user/index',
            title: '通知设置',
            icon: 'el-icon-adm-organization'
          },
          {
            path: '/access/index',
            title: '添加子账号',
            icon: 'el-icon-adm-user'
          },
          {
            path: '/log/index',
            title: '事务移交',
            icon: 'el-icon-adm-log'
          },
          {
            path: '/form/render',
            title: '账户管理',
            icon: 'el-icon-adm-form'
          }
          // {
          //   path: '/test/index',
          //   title: '测试',
          //   icon: 'el-icon-adm-formsetup'
          // }
        ],
        sider_menu_data0: [
          {
            path: '/home',
            title: '事务管理',
            icon: 'el-icon-adm-home'
          },
          {
            path: '/system/index',
            title: '过期事务',
            icon: 'el-icon-adm-project'
          },
          {
            path: '/user/index',
            title: '通知设置',
            icon: 'el-icon-adm-organization'
          },
          {
            path: '/log/index',
            title: '事务移交',
            icon: 'el-icon-adm-log'
          },
          {
            path: '/form/render',
            title: '账户管理',
            icon: 'el-icon-adm-form'
          }
          // {
          //   path: '/test/index',
          //   title: '测试',
          //   icon: 'el-icon-adm-formsetup'
          // }
        ],
        isCollapsed: false,
        adminMenuShow: false
      }
    },
    mounted() {
      this.typeData()
    },
    methods: {
      typeData() {
        let type = this.$store.state.type;
        this.type = type;
        let token = this.$store.state.token;
        this.axios.get('/customer/user/' + token)
        .then(response => {
          console.log(response);
          if (response.code === '200') {
            this.user = response.result;
          } else {
            this.$message({
              showClose: true,
              message: response.msg,
              type: 'error'
            });
          }
        })
        .catch(function (error) {
          console.log(error);
        });
      },
      checkAuth() {
        let token = this.$store.state.token || sessionStorage.getItem('token');
        if (!token) {
          this.$router.replace('/login');
        } else {
          this.getUser();
        }
      },
      getUser() {
        let User = {
          id: '7f859967-9b12-441c-badc-8a7d312f6da4',
          username: 'admin',
          name: 'luichooy'
          // type: {
          //   code: 0,
          //   name: '超级管理员'
          // }
        };
        
        this.$store.commit('SET_USER', User);
      },
      handleCommand(command) {
        console.log(command);
      },
      toggleMenu() {
        this.isCollapsed = !this.isCollapsed;
      },
      exit() {
        this.$confirm('即将退出系统登陆，是否继续？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
        .then(() => {
          this.axios.get('/customer/exit')
          .then(response => {
            console.log(response);
            if (response.code === '200') {
              this.$message({
                showClose: true,
                message: response.msg,
                type: 'success'
              });
            } else {
              this.$message({
                showClose: true,
                message: response.msg,
                type: 'error'
              });
            }
            this.$store.commit('SET_TOKEN', '');
            this.$store.commit('SET_USER', null);
            this.$router.replace({path: '/login'});
          })
          .catch(function (error) {
            console.log(error);
          }); 
        })
        .catch(() => {
          return false;
        })
      }
    }
  }
</script>
<style lang="scss">
  @import '../../assets/styles/variable';
  .user_info{
    display: flex;
    align-items: center;
  }
  .user_headimg{
    width: 26px;
    height: 26px;
    border-radius: 50%;
    margin-right: 10px;
  }
  .siderbar-wrapper {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    width: $siderbarWidth;
    z-index: 11;
    background-color: $leftNavBackgroundColor;
    transition: all 0.3s ease-in-out;
    
    .logo-wrapper {
      height: 40px;
      line-height: 40px;
      padding: 16px 0;
      text-align: center;
      font-size: 24px;
      color: #FFFFFF;
    }
    
    .menu-wrapper {
      position: absolute;
      top: 72px;
      bottom: 0;
      width: 100%;
      border-right: none;
      transition: all 0.3s ease-in-out;
      background-color: $leftNavBackgroundColor!important;
      &:not(.el-menu--collapse) {
        overflow-y: auto;
        overflow-x: hidden;
      }
      
      i {
        color: #FFFFFF;
      }
      
      .menu-item {
        
        &.is-active, &:hover {
          background-color: #0ba8f0 !important;
          color: #fff !important;
          
          i {
            color: #fff !important;
          }
        }
        
      }
      
      .el-submenu__title:hover {
        color: #65CEA7 !important;
        
        i {
          color: #65CEA7 !important;
        }
      }
      
      .el-submenu, .el-menu-item {
        width: 100%;
        background-color: $leftNavBackgroundColor!important;
        text-align: left;
      }
    }
  }
  
  .topbar-wrapper {
    position: fixed;
    left: $siderbarWidth;
    right: 0;
    top: 0;
    heihgt: $topbarHeight;
    line-height: $topbarHeight;
    padding: 0 24px 0 0;
    background-color: $topbarBackgroundColor;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .12), 0 0 6px 0 rgba(0, 0, 0, .04);
    transition: all 0.3s ease-in-out;
    z-index: 12;
    
    .menu-collapse-wrapper {
      height: 100%;
      width: 48px;
      text-align: center;
      cursor: pointer;
      
      i {
        transition: all 0.3s ease-in-out;
      }
    }
    
    .title {
      height: 100%;
      font-weight: bold;
    }
    
    .menu-list {
      .menu-item {
        position: relative;
        float: left;
        padding: 0 15px;
        min-width: 45px;
        height: 48px;
        text-align: center;
        font-size: 0px;
        
        &:hover {
          cursor: pointer;
          background-color: #F5F5F5;
        }
        
        .icon {
          vertical-align: middle;
          font-size: 24px;
        }
        
        .text {
          display: inline-block;
          vertical-align: middle;
          margin-left: 4px;
          font-size: 16px;
        }
      }
    }
  }
  
  .content-wrapper {
    position: fixed;
    left: $siderbarWidth;
    right: 0;
    top: $topbarHeight;
    bottom: 0;
    padding: 30px 50px;
    overflow: auto;
    transition: all 0.3s ease-in-out;
    
    .content {
      position: relative;
      width: 100%;
      height: 100%;
    }
  }
</style>
