//账户管理
<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/homeadd">
        <el-button type="primary">添加新事务<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="common_body">
      <div class="common_body_head">账户管理</div>
      <div class="notifications_settings_body">
        <el-form :model="ruleForm" status-icon :rules="rules2" ref="ruleForm" label-width="130px" class="demo-ruleForm">
          <el-form-item label="登录密码" prop="pass">
            <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="checkPass">
            <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">&nbsp;&nbsp;&nbsp;&nbsp;提&nbsp;&nbsp;交&nbsp;&nbsp;&nbsp;&nbsp;</el-button>
          </el-form-item>               
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入登录密码'));
        } else {
          if (this.ruleForm.checkPass !== '') {
            this.$refs.ruleForm.validateField('checkPass');
          }
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.ruleForm.pass) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
      return {
        input10: '',
        ruleForm: {
          pass: '',
          checkPass: ''
        },
        rules2: {
          pass: [
            { required: true, validator: validatePass, trigger: 'blur' }
          ],
          checkPass: [
            { required: true, validator: validatePass2, trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            alert('submit!');
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      }
    },
    mounted () {
      
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../../assets/styles/variable.scss';
.common_body{
  .notifications_settings_body{
    width: 500px;
  }
}
</style>

