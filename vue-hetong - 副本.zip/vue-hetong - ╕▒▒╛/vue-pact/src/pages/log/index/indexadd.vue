//确认移交
<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/log/indexadd">
        <el-button type="primary">确认移交<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="common_body">
      <table>
        <thead>
          <tr>
            <th width="55"><span></span></th>
            <th width="100">状态</th>
            <th width="120">到期时间</th>
            <th>标题</th>
            <th>联系人</th>
            <th>联系方式</th>
            <th width="160">操作</th>
          </tr>
        </thead>
      </table>
      <el-form label-width="130px">
        <el-form-item label="选择移交人">
          <el-select v-model="value8" filterable placeholder="点击下拉选择移交人" style="width:1000">
            <el-option
              v-for="item in options"
              :key="item.id"
              :label="item.phone"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <el-button type="primary" @click="submitForm">提交</el-button>
    </div>
  </div>
</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      return {
        input10: '',
        options: [],
        value8: ''
      }
    },
    methods: {
      submitForm() {
        console.log(this.value8)
        if (this.value8 === '') {
          this.$message({
            message: '没有选择移交人',
            type: 'warning'
          });
        }
      },
      handoverList() {
        let token = this.$store.state.token;
        this.axios.get('/customer/getEmployee/' + token)
        .then(response => {
          console.log(response);
          if (response.code === '200') {
            this.options = response.result;
          } else {
            this.$message({
              showClose: true,
              message: response.msg,
              type: 'error'
            });
          }
        })
        .catch(function (error) {
          console.log(error);
        });
      }
    },
    mounted () {
      this.handoverList();
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../../assets/styles/variable.scss';
.common_body{
  table{
    border-collapse:collapse;
    border: none;
    color: #fff;
    width: 100%;
    margin-bottom: 50px;
    thead{
      tr{
        background: #0ba8f0;
        height: 46px;
        line-height: 46px;
        font-size: 14px;
        th{
          height: 46px;
          line-height: 46px;
          span{
            width: 13px;
            height: 13px;
            display: inline-block;
            background: #fff;
            border-radius: 3px;
          }
        }
      }
    }
  }
  button{
    margin-left: 150px;
  }
  .el-button--primary{
    padding: 12px 50px;
    margin-top: 10px;
  }
}
</style>
