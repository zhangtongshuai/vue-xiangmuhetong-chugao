//事务移交
<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/log/indexadd">
        <el-button type="primary">确认移交<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <contracts-list></contracts-list>
  </div>
</template>
<script>
  import contractsList from 'src/components/ContractsList/index';
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      return {

      }
    },
    methods: {
      
    },
    mounted () {
      
    },
    components: {
      contractsList,
      searchBox
    }
  }
</script>
<style lang="scss" scoped>

</style>
