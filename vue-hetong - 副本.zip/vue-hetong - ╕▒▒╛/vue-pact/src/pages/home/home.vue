<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/homeadd">
        <el-button type="primary">添加新事务<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <contracts-list></contracts-list>
  </div>
</template>
<script>
  import contractsList from 'src/components/ContractsList/index';
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      return {
        
      }
    },
    methods: {

    },
    mounted () {
      
    },
    components: {
      contractsList,
      searchBox
    }
  }
</script>
<style lang="scss" scoped>

</style>
