<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/homeadd">
        <el-button type="primary">添加新事务<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="homeadd_body">
        <div class="homeadd_body_head">添加新事务</div>
        <div class="homeadd_info">
          <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="130px" class="demo-ruleForm">
            <div class="homeadd_info_head">
                <div class="homeadd_info_head_left">
                        <el-form-item label="标题" prop="title">
                            <el-input type="text" v-model="ruleForm2.title" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="联系人" prop="contact">
                            <el-input type="text" v-model="ruleForm2.contact" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="单独邮件提醒" prop="email">
                            <el-input type="email" v-model="ruleForm2.email" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="单独电话提醒" prop="phone">
                            <el-input type="text" v-model="ruleForm2.phone" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="时间提醒" prop="time">
                            <el-col :span="24">
                                <el-date-picker placeholder="选择日期" v-model="ruleForm2.time" style="width: 100%;"></el-date-picker>
                            </el-col>
                        </el-form-item>
                </div>
                <div class="homeadd_info_head_right">
                    <div class="upload_info">
                        <div class="com-upload-img">
                            <div class="img_group">
                                <div class="img_box" v-for="(item,index) in imgArr" :key="index">
                                    <div class="img_show_box">
                                        <img :src="item" alt="">
                                        <i class="el-icon-delete" @click="deleteImg(index)"></i>
                                        <!-- <i class="el-icon-delete" @click="imgArr.splice(index,1)"></i> -->
                                    </div>
                                </div>
                            </div>
                            <div class="upload_btn" v-if="allowAddImg">
                              <el-button type="primary">点击上传附件<i class="el-icon-upload el-icon--right"></i></el-button>
                              <input type="file" class="upload_input" accept="image/*" multiple="multiple" @change="changeImg($event)">
                              <!-- <div class="filter"></div> -->
                            </div>
                        </div>
                    </div>
                    <div class="upload_remarks">附件要求说明：最多上传4个附件，单个附件最大不超过50KB</div>
                </div>
            </div>
            <div class="homeadd_info_bottom">
                <div class="homeadd_info_bottom_title"><span></span>事务详情</div>
                <el-form-item label="事务详情" prop="content">
                  <el-input type="textarea" placeholder="请在此输入事务详情" v-model="ruleForm2.content"></el-input>
                </el-form-item>
            </div>
          </el-form>
        </div>
        <div class="homeadd_foot">
           <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
        </div>
    </div>
  </div>
</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      var validatePhone = (rule, value, callback) => {
        let reg = /^1[345789]\d{9}$/;
        if (value === '') {
          callback(new Error('请输入手机号'));
        } else {
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('请输入正确的手机号'));
          }
        }  
      };
      return {
        imgArr: [],
        allowAddImg: true,
        input10: '',
        ruleForm2: {
          title: '',
          contact: '',
          email: '',
          phone: '',
          time: '',
          content: ''
        },
        rules2: {
          title: [
            { required: true, message: '请输入活动名称', trigger: 'blur' }
          ],
          contact: [
            { required: true, message: '请输入联系人', trigger: 'blur' }
          ],
          email: [
            { required: true, message: '请输入邮箱地址', trigger: 'blur' },
            { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
          ],
          phone: [
            { required: true, validator: validatePhone, trigger: ['blur', 'change'] }
          ],
          time: [
            { type: 'date', required: true, message: '请选择日期', trigger: 'blur' }
          ],
          content: [
            { required: true, message: '请输入事务详情', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      getBase64(file) {   
        var reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {     
          console.log(reader.result);
        };
        reader.onerror = function (error) {     
          console.log('Error: ', error);
        };
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log(valid)
            var file1 = '';
            var file2 = '';
            var file3 = '';
            var file4 = '';
            if (this.imgArr !== '') {
              if (this.imgArr.length === 1) {
                file1 = this.imgArr[0];
                file2 = '';
                file3 = '';
                file4 = '';
              } else if (this.imgArr.length === 2) {
                file1 = this.imgArr[0];
                file2 = this.imgArr[1];
                file3 = '';
                file4 = '';
              } else if (this.imgArr.length === 3) {
                file1 = this.imgArr[0];
                file2 = this.imgArr[1];
                file3 = this.imgArr[2];
                file4 = '';
              } else if (this.imgArr.length === 4) {
                file1 = this.imgArr[0];
                file2 = this.imgArr[1];
                file3 = this.imgArr[2];
                file4 = this.imgArr[3];
              }
            }
            let token = this.$store.state.token;
            let title = this.ruleForm2.title;
            let contact = this.ruleForm2.contact;
            let contactphone = this.ruleForm2.phone;
            let overtime = this.ruleForm2.time;
            let date = new Date(overtime);  
            let dateValue = date.getFullYear() + '-' + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1)) + '-' + (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()); 
            let contactemail = this.ruleForm2.email;
            let content = this.ruleForm2.content;
            this.axios.post('/agreement/addAgreement', {
              token: token,
              title: title,
              contact: contact,
              contactphone: contactphone,
              overtime: dateValue,
              contactemail: contactemail,
              content: content,
              file1: file1,
              file2: file2,
              file3: file3,
              file4: file4
            })
            .then(response => {
              console.log(response);
              if (response.code === '200') {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'success'
                });
                this.$router.push({path: '/home'})
              } else {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'error'
                });
              }
            })
            .catch(function (error) {
              console.log(error);
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      changeImg(e) {
        var _this = this;
        var imgLimit = 1024;
        var files = e.target.files;
        var image = new Image();
        if (files.length > 0) {
          var dd = 0;
          var timer = setInterval(() => {
            if (files.item(dd).type !== 'image/png' && files.item(dd).type !== 'image/jpeg' && files.item(dd).type !== 'image/gif') {
              return false;
            }
            if (files.item(dd).size > imgLimit * 50) {
              this.$message({
                showClose: true,
                message: '单个文件最大不能超过50KB',
                type: 'error'
              });
            } else {
              image.src = window.URL.createObjectURL(files.item(dd));
              image.onload = function() {
                var w = image.width;
                var h = image.height;
                var scale = w / h;
                w = 200;
                h = w / scale;
                // 默认图片质量为0.7，quality值越小，所绘制出的图像越模糊
                var quality = 0.8;
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');
                // 创建属性节点
                var anw = document.createAttribute('width');
                anw.nodeValue = w;
                var anh = document.createAttribute('height');
                anh.nodeValue = h;
                canvas.setAttributeNode(anw);
                canvas.setAttributeNode(anh);
                ctx.drawImage(image, 0, 0, w, h);
                var ext = image.src.substring(image.src.lastIndexOf('.') + 1).toLowerCase();
                var base64 = canvas.toDataURL('image/' + ext, quality);
                // 回调函数返回base64的值
                if (_this.imgArr.length <= 3) {
                  _this.imgArr.unshift('');
                  _this.imgArr.splice(0, 1, base64);
                  if (_this.imgArr.length >= 4) {
                    _this.allowAddImg = false;
                  }
                }
              }
            }
            if (dd < files.length - 1) {
              dd++;
            } else {
              clearInterval(timer);
            }
          }, 1000)
        }
      },
      deleteImg: function(index) {
        this.imgArr.splice(index, 1);
        if (this.imgArr.length < 4) {
          this.allowAddImg = true;
        }
      }
    },
    mounted () {
      
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../assets/styles/variable.scss';
.homeadd_body{
    margin-top: 30px;
    background: #fff;
    .homeadd_body_head{
      height: 48px;
      line-height: 48px;
      background: #0ba8f0;
      font-size: 14px;
      color: #fff;
      padding-left: 20px;
      margin-bottom: 50px;
    }
    .homeadd_info{
        padding: 25px 50px;
        .homeadd_info_head{
            display: flex;
            flex-flow: row wrap;
            justify-content: space-around;
            .homeadd_info_head_left{
                width: 35%;
                padding-right: 10%;
                padding-left: 5%;
                padding-top: 20px;
            }
            .homeadd_info_head_right{
                width: 42%;
                margin: 0 4%;
                display: flex;
                justify-content: center;
                flex-direction: column;
                align-items: center;
                background: #f6f6f6;
                display: flex;
                padding: 10px 0;
                .upload_remarks{
                    margin-top: 20px;
                    font-size: 12px;
                    color: #777;
                }
                .com-upload-img{
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  .img_group{
                    display: flex;
                    .img_box{
                      img{
                        width: 120px;
                        height: 160px;
                      }
                      i{
                        color: #999;
                        cursor: pointer;
                      }
                    }
                  }
                  .upload_btn{
                    margin-top: 20px;
                    position: relative;
                    overflow: hidden;
                    .upload_input{
                      position: absolute;
                      left: 0;
                      top:0;
                      width: 145px;
                      height: 42px;
                      cursor: pointer;
                      opacity: 0;
                      -ms-filter: 'alpha(opacity=0)';
                      font-size: 30px;
                    }
                  }
                }
            }
        }
        .homeadd_info_bottom{
            margin-top: 50px;
            background: #f6f6f6;
            padding:0 20px 20px;
            border-radius: 5px;
            .homeadd_info_bottom_title{
                span{
                    display: inline-block;
                    width: 5px;
                    height: 14px;
                    background: rgb(11, 168, 240);
                    margin-right: 5px;
                }
                font-size: 16px;
                color: rgb(11, 168, 240);
                height: 40px;
                line-height: 40px;
                display: flex;
                align-items: center;
            }
            textarea{
                margin-top: 10px;
                font-size: 14px;
                border:none;
                background: #f6f6f6;
                width: 100%;
                min-height: 200px;
                color: #333;
                ::placeholder{
                    color: #eee;
                }
            }
        }
    }
    .homeadd_foot{
        text-align: center;
        .el-button--primary{
            padding: 12px 50px;
        }
        padding-bottom: 50px;
    }
}
</style>
