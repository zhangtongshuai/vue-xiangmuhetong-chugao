<template>
  <div class="login">
    <div class="middle-wrapper">
      <div class="login-form">
        <el-form
          ref="loginForm"
          :model="form"
          :rules="rules">
          <div class="account_switching">
            <div class="account_switching_list" @click="personalLogin()">
              <div>个人登录</div>
              <span v-if="ltype === 0"></span>
            </div>
            <div class="account_switching_list" @click="companyLogin()">
              <div>企业登录</div>
              <span v-if="ltype === 1"></span>
            </div>
          </div>
          <el-form-item prop="username">
            <el-input v-model="form.username" placeholder="请输入账号">
              <i slot="prefix" class="el-input__icon el-icon-adm-user" style="font-size: 18px;"></i>
            </el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input :type="passwordType" v-model="form.password" placeholder="请输入密码">
              <i slot="prefix" class="el-input__icon el-icon-adm-password" style="font-size: 18px;"></i>
              <i slot="suffix" class="el-input__icon el-icon-view" style="cursor: pointer;"
                 @click="_togglePasswordType"></i>
            </el-input>
          </el-form-item>
          <el-form-item prop="yanzhengma">
            <div class="check-code-wrapper">
              <div class="yanzhengma-wrapper">
                <el-input v-model="form.yanzhengma" @keyup.enter.native="login('loginForm')" placeholder="请输入验证码">
                  <i slot="prefix" class="el-input__icon el-icon-adm-vertification" style="font-size: 18px;"></i>
                </el-input>
              </div>
              <div class="validate-code-wrapper">
                <validate-code ref="validate-code" @change="_setCheckCode"></validate-code>
              </div>
            </div>
          </el-form-item>
          <el-form-item style="margin-bottom: 0;">
            <el-col :span="10" :offset="14">
              <el-form-item>
                <el-button
                  type="primary"
                  class="login-btn"
                  style="width: 100%;"
                  @click="loginHandle('loginForm')">
                  登陆
                </el-button>
              </el-form-item>
            </el-col>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
  import validateCode from 'src/components/ValidateCode/index';
  export default {
    created () {
    },
    data () {
      var checkYanzhengma = (rule, value, callback) => {
        value = value.toUpperCase();
        if (value === '') {
          callback(new Error('请输入验证码'));
        } else if (value !== this.checkCode) {
          callback(new Error('验证码错误'));
          this.$refs['validate-code'].draw();
        } else {
          callback();
        }
      };
      var validatePhone = (rule, value, callback) => {
        let reg = /^1[345789]\d{9}$/;
        if (value === '') {
          callback(new Error('请输入手机号'));
        } else {
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('请输入正确的手机号'));
          }
        }  
      };
      return { 
        ltype: 0,
        passwordType: 'password',
        checkCode: '',
        form: {
          username: '',
          password: '',
          yanzhengma: ''
        },
        rules: {
          username: [
            { required: true, validator: validatePhone, trigger: ['blur', 'change'] }
          ],
          password: [
            { required: true, message: '密码不能为空', trigger: 'blur' }
          ],
          yanzhengma: [
            { validator: checkYanzhengma, trigger: 'blur' }
          ]
        }
      };
    },
    methods: {
      personalLogin() {
        this.ltype = 0;
      },
      companyLogin() {
        this.ltype = 1; 
      },
      _setCheckCode (value) {
        this.checkCode = value;
      },
      _togglePasswordType () {
        if (this.passwordType === 'password') {
          this.passwordType = 'text';
        } else {
          this.passwordType = 'password';
        }
      },
      loginHandle (formName) {
        this.$refs[formName].validate(valid => {
          console.log(this.GLOBAL.baseURL)
          if (valid) {
            this.login();
          }
        });
      },
      login () {
        /*
         *  在这边可以进行登陆请求
         *  将请求返回的Token对象存到store中
         *  @Token  token对象
        */
        this.axios.post('/customer/login', {
          phone: this.form.username,
          password: this.form.password,
          type: this.ltype
        })
        .then(response => {
          console.log(response);
          if (response.code === '200') {
            // this.$router.replace('home');
            // this.$router.push({path: '/home'});
            let token = response.result.token;
            let type = response.result.type;
            let realname = response.result.realname;
            let phone = response.result.phone;
            this.$store.commit('SET_TOKEN', token);
            this.$store.commit('TYPE', type);
            this.$store.commit('REAL_NAME', realname);
            this.$store.commit('PHONE', phone);
            this.$message({
              showClose: true,
              message: response.msg,
              type: 'success'
            });
            this.$router.replace('home');
          } else {
            this.$message({
              showClose: true,
              message: response.msg,
              type: 'error'
            });
          }
        })
        .catch(function (error) {
          console.log(error);
        });
      }
    },
    components: {
      validateCode
    }
  };
</script>
<style lang="scss" scoped>
  .login {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background: url('../../assets/images/bj.png') no-repeat center;

    .middle-wrapper {
      position: fixed;
      width: 100%;
      margin: 0 auto;
      top: 50%;
      transform: translateY(-60%);

      .login-form {
        position: relative;
        margin: 0 auto;
        width: 640px;
        padding: 30px 100px 50px;
        box-sizing: border-box;
        border-radius: 5px;
        background: rgba($color: #aaa, $alpha: 0.3);
        box-shadow:#aaa 0px 0px 20px;
        
        .account_switching{
          display: flex;
          justify-content: center;
          margin-bottom: 60px;
          .account_switching_list{
            padding: 0 25px;
            font-size: 24px;
            color: #fff;
            display: flex;
            align-items: center;
            flex-flow: column;
            font-weight: bold;
            cursor: pointer;
            span{
              display: inline-block;
              width: 66px;
              height: 3px;
              background: #fff;
              margin-top: 15px;
            }
          }
        }
        .el-col-offset-14{
          margin:0;
          display: flex;
          justify-content: center;
          width: 100%;
        }
        .el-button{
          padding: 15px 80px;
          font-size: 22px;
          margin-top: 20px;
        }
        .el-button--primary{
          background-color:#fff;
          border-color: #fff;
          color: #409EFF;
          &:hover{
            background-color:#ecf5ff;

          }
        }
        .el-row {
          margin-bottom: 20px;

          &:last-child {
            margin-bottom: 0;
          }

          .login-btn {
            width: 100%;
          }
        }
        
        .check-code-wrapper {
          display: flex;
          justify-content: space-between;
          height: 40px;

          .yanzhengma-wrapper {
            flex: 0 1 auto;
          }

          .validate-code-wrapper {
            flex: 0 0 160px;
          }
        }
      }
    }
  }
</style>
