//添加子账号
<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/access/indexadd">
        <el-button type="primary">添加子账号<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="common_body">
      <div class="common_body_head">添加子账号</div>
      <div class="account_add">
        <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="130px" class="demo-ruleForm">
          <el-form-item label="手机号" prop="phone">
            <el-input v-model="ruleForm.phone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="联系人" prop="name">
            <el-input v-model="ruleForm.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="职务" prop="job">
            <el-input v-model="ruleForm.job" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="登录密码" prop="pass">
            <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="checkPass">
            <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="status">
            <el-radio-group v-model="ruleForm.status">
              <el-radio label="开通"></el-radio>
              <el-radio label="暂停"></el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">&nbsp;&nbsp;&nbsp;&nbsp;确&nbsp;&nbsp;认&nbsp;&nbsp;&nbsp;&nbsp;</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      var validatePhone = (rule, value, callback) => {
        let reg = /^1[345789]\d{9}$/;
        if (value === '') {
          callback(new Error('请输入手机号'));
        } else {
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('请输入正确的手机号'));
          }
        }  
      };
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入登录密码'));
        } else {
          if (this.ruleForm.checkPass !== '') {
            this.$refs.ruleForm.validateField('checkPass');
          }
          callback();
        }
      };
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.ruleForm.pass) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
      return {
        input10: '',
        ruleForm: {
          phone: '',
          name: '',
          job: '',
          pass: '',
          checkPass: '',
          status: '开通'
        },
        rules: {
          phone: [
            { required: true, validator: validatePhone, trigger: ['blur', 'change'] }
          ],
          name: [
            { required: true, message: '请填写联系人', trigger: ['blur'] }
          ],
          job: [
            { required: true, message: '请填写职务', trigger: ['blur'] }
          ],
          pass: [
            { required: true, validator: validatePass, trigger: 'blur' }
          ],
          checkPass: [
            { required: true, validator: validatePass2, trigger: 'blur' }
          ],
          status: [
            { required: true, message: '请选择状态', trigger: 'change' }
          ]
        }
      }
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let activeflag;
            if (this.ruleForm.status === '开通') {
              activeflag = 1
            } else {
              activeflag = 2
            }
            console.log(activeflag);
            this.axios.post('/customer/addEmployee', {
              token: this.$store.state.token,
              phone: this.ruleForm.phone,
              realname: this.ruleForm.name,
              note: this.ruleForm.job,
              newPassword: this.ruleForm.pass,
              confirmPassword: this.ruleForm.checkPass,
              activeflag: activeflag
            })
            .then(response => {
              console.log(response);
              if (response.code === '200') {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'success'
                });
                this.$router.push({path: '/access/index'})
              } else {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'error'
                });
              }
            })
            .catch(function (error) {
              console.log(error);
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      }
    },
    mounted () {
      
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../../assets/styles/variable.scss';
  .account_add{
    width:500px;
  }
</style>