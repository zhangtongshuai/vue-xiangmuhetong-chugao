//添加子账号
<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/access/indexadd">
        <el-button type="primary">添加子账号<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="common_body">
      <el-table
        show-header
        stripe
        ref="multipleTable"
        :data="affairData"
        tooltip-effect="dark"
        style="width: 100%"
        :cell-style="tableTdStyle"
        :header-cell-style="tableHeaderColor">
        <el-table-column
          label="子账号"
          prop="phone"
          width="240">
        </el-table-column>
        <el-table-column
          prop="activeflag"
          label="状态">
        </el-table-column>
        <el-table-column
          prop="realname"
          label="联系人">
        </el-table-column>
        <el-table-column
          prop="note"
          label="职务">
        </el-table-column>
        <el-table-column label="操作" width="200">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="edit"
              @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
              <el-button
              size="mini"
              type="delete"
              @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="编辑子账号" :visible.sync="dialogFormVisible" :modal-append-to-body="false" width="500px">
      <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="130px" class="demo-ruleForm">
          <el-form-item label="联系人" prop="realname">
            <el-input v-model="ruleForm.realname" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="职务" prop="note">
            <el-input v-model="ruleForm.note" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="activeflag">
            <el-radio-group v-model="ruleForm.activeflag">
              <el-radio label="开通"></el-radio>
              <el-radio label="暂停"></el-radio>
            </el-radio-group>
          </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitForm('ruleForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>

</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      return {
        input10: '',
        affairData: [],
        dialogFormVisible: false,
        ruleForm: {
          countid: '',
          realname: '',
          note: '',
          activeflag: ''
        },
        rules: {
          activeflag: [
            { required: true, message: '请选择状态', trigger: 'change' }
          ]
        },
        formLabelWidth: '100px'
      }
    },
    methods: {
      tableTdStyle() {
        return 'text-align:center;'
      },
      tableHeaderColor({ row, column, rowIndex, columnIndex }) {
        if (rowIndex === 0) {
          return 'background-color: #0ba8f0;color: #fff;font-weight: bold;text-align:center;'
        }
      },
      handleEdit(index, row) {
        console.log(row);
        this.dialogFormVisible = true;
        this.ruleForm.countid = row.id;
        this.ruleForm.realname = row.realname;
        this.ruleForm.note = row.note;
        this.ruleForm.activeflag = row.activeflag;
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let token = this.$store.state.token;
            let countid = this.ruleForm.countid;
            let realname = this.ruleForm.realname;
            let note = this.ruleForm.note;
            var activeflag;
            if (this.ruleForm.activeflag === '开通') {
              activeflag = 1
            } else {
              activeflag = 2
            }
            this.axios.post('/customer/editAccount', {
              token: token,
              countid: countid,
              realname: realname,
              note: note,
              activeflag: activeflag
            })
            .then(response => {
              console.log(response);
              if (response.code === '200') {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'success'
                });
                this.subaccountInfo();
                this.dialogFormVisible = false;
              } else {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'error'
                });
              }
            })
            .catch(function (error) {
              console.log(error);
            });
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      handleDelete(index, row) {
        console.log(index, row);
        let token = this.$store.state.token;
        let countid = row.id
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.axios.get('/customer/delAccount/' + token + '/' + countid)
          .then(response => {
            console.log(response);
            if (response.code === '200') {
              this.$message({
                showClose: true,
                message: response.msg,
                type: 'success'
              });
              this.subaccountInfo();
            } else {
              this.$message({
                showClose: true,
                message: response.msg,
                type: 'error'
              });
            }
          })
          .catch(function (error) {
            console.log(error);
          }); 
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });     
      },
      subaccountInfo() {
        let token = this.$store.state.token;
        this.axios.get('/customer/getAccounts/' + token)
        .then(response => {
          console.log(response);
          if (response.code === '200') {
            response.result.forEach(element => {
              if (element.activeflag === 1) {
                element.activeflag = '开通'
              } else {
                element.activeflag = '禁止'
              }
            });
            this.affairData = response.result;
          } else {
            this.$message({
              showClose: true,
              message: response.msg,
              type: 'error'
            });
          }
        })
        .catch(function (error) {
          console.log(error);
        });
      }
    },
    mounted () {
      this.subaccountInfo();
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../../assets/styles/variable.scss';
</style>