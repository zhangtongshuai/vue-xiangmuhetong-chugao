//通知设置
<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/homeadd">
        <el-button type="primary">添加新事务<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="common_body">
      <div class="notifications_settings_head">通知设置</div>
      <div class="notifications_settings_body">
        <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="130px" class="demo-ruleForm">
          <el-form-item label="消息通知邮箱" prop="email">
            <el-input type="email" v-model="ruleForm2.email" autocomplete="off"></el-input>
          </el-form-item> 
          <el-form-item label="验证码" prop="code">
            <el-row :gutter="20" type="flex" justify="space-between">
              <el-col :span="16">
              <el-input type="text" v-model="ruleForm2.code" autocomplete="off"></el-input>
              </el-col>
              <el-col :span="8">
              <el-button type="primary" @click="sendCode('email')">发送验证码</el-button>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm2')">&nbsp;&nbsp;&nbsp;&nbsp;提&nbsp;&nbsp;交&nbsp;&nbsp;&nbsp;&nbsp;</el-button>
          </el-form-item>               
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      return {
        input10: '',
        ruleForm2: {
          email: '',
          code: ''
        },
        rules2: {
          email: [
            { required: true, message: '请输入邮箱地址', trigger: 'blur' },
            { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
          ],
          code: [
            { required: true, message: '请输入验证码', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      sendCode() {
        if (this.ruleForm2.email === '') {
          this.$message({
            message: '请先填写消息通知邮箱',
            showClose: true,
            type: 'warning',
            duration: 2000
          });
          return false;
        } else {
          this.axios.post('/customer/getEmailcode', {
            email: this.ruleForm2.email,
            token: this.$store.state.token
          })
          .then(response => {
            console.log(response);
            if (response.code === '200') {
              this.$message({
                showClose: true,
                message: response.msg,
                type: 'success'
              });
            } else {
              this.$message({
                showClose: true,
                message: response.msg,
                type: 'error'
              });
            }
          })
          .catch(function (error) {
            console.log(error);
          }); 
        }
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.axios.post('/customer/updateInfo', {
              phone: this.ruleForm2.email,
              token: this.$store.state.token,
              type: 1,
              code: this.ruleForm2.code
            })
            .then(response => {
              console.log(response);
              if (response.code === '200') {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'success'
                });
                this.ruleForm2.email = '';
                this.ruleForm2.code = '';
              } else {
                this.$message({
                  showClose: true,
                  message: response.msg,
                  type: 'error'
                });
              }
            })
            .catch(function (error) {
              console.log(error);
            }); 
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      }
    },
    mounted () {
      
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../../assets/styles/variable.scss';
.common_body{
  .notifications_settings_head{
    height: 48px;
    line-height: 48px;
    background: #0ba8f0;
    font-size: 14px;
    color: #fff;
    padding-left: 20px;
    margin-bottom: 50px;
  }
  .notifications_settings_body{
    width: 500px;
  }
}
</style>

