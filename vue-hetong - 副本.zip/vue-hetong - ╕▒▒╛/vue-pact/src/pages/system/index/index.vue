<template>
  <div class="common">
    <div class="common_head">
      <router-link to="/homeadd">
        <el-button type="primary">添加新事务<i class="el-icon-plus el-icon--right"></i></el-button>
      </router-link>
      <search-box></search-box>
    </div>
    <div class="common_body">
      <el-table
        show-header
        stripe
        :data="affairData.slice((currentPage3-1)*pagesize,currentPage3*pagesize)"
        ref="multipleTable"
        tooltip-effect="dark"
        style="width: 100%"
        :cell-style="tableTdStyle"
        :header-cell-style="tableHeaderColor"
        @selection-change="handleSelectionChange">
        <el-table-column
          type="selection"
          width="55">
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template slot-scope="scope">
            <el-button
              prop="state"
              size="mini"
              type="overdue"
              @click="handleOverdue(scope.$index, scope.row)" v-show="scope.row.state === 4">过期</el-button>
          </template>
        </el-table-column>
        <el-table-column
          prop="overtime"
          label="到期时间"
          width="130">
        </el-table-column>
        <el-table-column
          prop="title"
          label="标题">
        </el-table-column>
        <el-table-column
          prop="contact"
          label="联系人">
        </el-table-column>
        <el-table-column
          prop="contactphone"
          label="联系方式">
        </el-table-column>
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="details"
              @click="handleDetails(scope.$index, scope.row)">详情</el-button>
            <el-button
              size="mini"
              type="edit"
              @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="common_foot">
      <div class="block">
        <el-pagination
          background
          :pager-count = "7"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage3"
          :page-sizes="[5, 10, 20, 40]"
          :page-size="pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="affairData.length">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
  import searchBox from 'src/components/SearchBox/index';
  export default {
    data() {
      return {
        pagesize: 10,
        currentPage3: 1,
        input10: '',
        affairData: [],
        multipleSelection: []
      }
    },
    methods: {
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      handleOverdue(index, row) {
        console.log(index, row);
      },
      handleDetails(index, row) {
        console.log(index, row);
        this.$alert('<strong>这是 <i>HTML</i> 片段</strong>', 'HTML 片段', {
          dangerouslyUseHTMLString: true,
          title: '合同详情'
        });
      },
      handleEdit(index, row) {
        console.log(index, row);
      },
      tableTdStyle() {
        return 'text-align:center;'
      },
      tableHeaderColor({ row, column, rowIndex, columnIndex }) {
        if (rowIndex === 0) {
          return 'background-color: #0ba8f0;color: #fff;font-weight: bold;text-align:center;'
        }
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
        this.pagesize = val;
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.currentPage3 = val;
      },
      add0(m) {
        return m < 10 ? '0' + m : m;
      },
      managementData(flag) {
        this.axios.post('/agreement/getAgreement', {
          token: this.$store.state.token,
          title: '',
          flag: flag
        })
        .then(response => {
          console.log(response);
          if (response.code === '200') {
            response.result.forEach(element => {
              var time = new Date(element.overtime);
              var y = time.getFullYear();
              var m = time.getMonth() + 1;
              var d = time.getDate();
              element.overtime = y + '-' + this.add0(m) + '-' + this.add0(d);
            });
            this.affairData = response.result;
          } else {
            this.$message({
              showClose: true,
              message: response.msg,
              type: 'error'
            });
          }
        })
        .catch(function (error) {
          console.log(error);
        });
      }
    },
    mounted () {
      this.managementData(4);
    },
    components: {
      searchBox
    }
  }
</script>
<style lang="scss" scoped>
@import '../../../assets/styles/variable.scss';
</style>
