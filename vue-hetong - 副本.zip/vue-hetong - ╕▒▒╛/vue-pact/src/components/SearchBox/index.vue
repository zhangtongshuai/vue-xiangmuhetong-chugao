<template>
    <div>
        <div class="search_box">
            <div class="search_info"><el-input placeholder="搜索内容" v-model="input10" style="background-color:#fff" clearable></el-input><el-button type="primary" icon="el-icon-search"></el-button></div>
            <div class="common_head_right_btns">
                <el-button type="danger">{{urgentnum}}</el-button>
                <el-button type="warning">{{waitnum}}</el-button>
                <el-button type="success">{{normalnum}}</el-button>
            </div>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      input10: '',
      normalnum: '',
      waitnum: '',
      urgentnum: ''
    }  
  },
  methods: {
    dataNum() {
      let token = this.$store.state.token;
      this.axios.get('/customer/user/' + token)
      .then(response => {
        console.log(response);
        if (response.code === '200') {
          this.user = response.result;
          let normalnum = response.result.normalnum;
          let urgentnum = response.result.urgentnum;
          let waitnum = response.result.waitnum;
          this.normalnum = normalnum;
          this.waitnum = waitnum;
          this.urgentnum = urgentnum;
        } else {
          this.$message({
            showClose: true,
            message: response.msg,
            type: 'error'
          });
        }
      })
      .catch(function (error) {
        console.log(error);
      });
    } 
  },
  mounted () {
    this.dataNum()
  }
}
</script>
<style lang="scss" scoped>
@import '../../assets/styles/variable.scss';
.search_box{
    display: flex;
    align-items: center;
    .search_info{
      display: flex;
      align-items: center;
      margin-left: 80px;
      .el-input{
        width: 565px;
      }
      .el-button{
        width: 100px;
      }
    }
    .common_head_right_btns{
      width: 100%;
      margin-left: 50px;
      text-align: right;
      display: flex;
      flex-flow: row nowrap;
      justify-content: center;
      .el-button{
        width:80px;
      }
    }
}
</style>


  